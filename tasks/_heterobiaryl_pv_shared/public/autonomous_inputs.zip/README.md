# Autonomous P(V) computation input package

This package contains only experimental measurements, chemical-system metadata, and deliberately unoptimized starting geometries. It contains no completed quantum-chemistry calculation or reference answer. Inspect `data_scope.json` before planning calculations.
